<!--
CÓMO USAR ESTA PLANTILLA (este bloque no se ve en GitHub; puede dejarlo o borrarlo)
1. Guarde este archivo con el nombre README.md dentro de la carpeta UA2/AC2_2da (no en UA2).
2. Cree la carpeta UA2/AC2_2da/recursos y guarde ahí las capturas con estos nombres exactos,
   sin espacios ni tildes: captura_p1.png, captura_p2.png y captura_p3.png.
3. Llene cada tabla. En «Pruebas realizadas» anote lo que su programa mostró de verdad.
4. Resuelva 2 de los 3 problemas. Anote abajo cuáles eligió, escriba «No elegido» debajo del
   título del problema que no resuelva y deje sus tablas vacías.
5. Haga commit del README junto con los programas y un push al final.
-->

# AC2 · 2.ª oportunidad · Mi primera aplicación en C

**Estudiante:** (nombre completo)  
**Fecha:** (dd/mm/2026)  
**Módulo:** CSTI12010 Diseño de algoritmos · UA2  
**Persona facilitadora:** Giovanni Antonio Coto Calderón  
**Problemas elegidos (2 de 3):** (por ejemplo, Problema 1 y Problema 3)

## Contenido de la carpeta

```
UA2/AC2_2da/
├── README.md
├── AC2B_P1_PagoTecnico.c      (si eligió el problema 1)
├── AC2B_P2_ConsumoAgua.c      (si eligió el problema 2)
├── AC2B_P3_Matricula.c        (si eligió el problema 3)
└── recursos/
    └── captura_p1.png, captura_p2.png o captura_p3.png (una por problema elegido)
```

---

## Problema 1 · Pago semanal del técnico (AC2B_P1_PagoTecnico.c)

### Análisis

| Datos de entrada | Proceso | Datos de salida | Limitaciones |
|---|---|---|---|
|nombre completo, horas trabajadas y la tarifa  | Se pide el nombre, las horas y la tarifa hastaque sean corretas, luego se calculan tarifa extra(si la hay), el pago ordinario, el salario bruto, la rebaja del seguro y el salario neto. |nombre del tecnico, pago ordinario, tarifa por horas extra, el salario bruto, rebajo del seguro social y el salario neto.  |Que las horas sean del 1 al 60 o se vuelve a pedir, que el nombre no este vacio o se vuelve a pedir y y que la tarifa sea mayor a 0 o se vuelve perdir.  |

### Pruebas realizadas

| Caso | Datos ingresados | Lo que mostró mi programa | ¿Correcto? |
|---|---|---|---|
| Ejemplo del enunciado | Jose Mora, 52, 2500 | mostro los datos correctos del pdf. | SI |
| Caso límite | (por ejemplo, exactamente 48 horas) | En este caso no hubo horas extra asi que los resultados de los calculos fueron diferentes pero, no erroneos. | Segun lo esperado |
| Dato inválido | (por ejemplo, nombre vacío, 0 horas o 61 horas) |Pidio de nuevo los valores hasta que fueran los correctos.| | Segun lo esperado |

### Ejecución con los datos del ejemplo

![Ejecución del problema 1](/UA2/AC2_2da/recursos/PagoTecnico_Evi.png)

---

## Problema 2 · Consumo de agua de un hogar (AC2B_P2_ConsumoAgua.c)

### Análisis

| Datos de entrada | Proceso | Datos de salida | Limitaciones |
|---|---|---|---|
|  |  |  |  |

### Pruebas realizadas

| Caso | Datos ingresados | Lo que mostró mi programa | ¿Correcto? |
|---|---|---|---|
| Ejemplo del enunciado | Familia Rojas, 18, 22, 35, 27, 20, 24 |  |  |
| Caso límite | (por ejemplo, un promedio de exactamente 30 o de 15) |  |  |
| Dato inválido | (por ejemplo, un consumo de 120 o de -5) |  |  |

### Ejecución con los datos del ejemplo

![Ejecución del problema 2](recursos/captura_p2.png)

---

## Problema 3 · Matrícula de cursos libres (AC2B_P3_Matricula.c)

### Análisis

| Datos de entrada | Proceso | Datos de salida | Limitaciones |
|---|---|---|---|
|  |  |  |  |

### Pruebas realizadas

| Caso | Datos ingresados | Lo que mostró mi programa | ¿Correcto? |
|---|---|---|---|
| Ejemplo del enunciado | Lucia Vargas, Excel basico (20 h, 1500), Ingles conversacional (40 h, 1200), Fotografia digital (16 h, 2000) |  |  |
| Caso límite | (por ejemplo, 1 solo curso, o 6 cursos) |  |  |
| Dato inválido | (por ejemplo, 0 horas o responder X en S/N) |  |  |

### Ejecución con los datos del ejemplo

![Ejecución del problema 3](recursos/captura_p3.png)

---

## Lista de verificación antes de entregar

Marque cada punto cambiando `[ ]` por `[x]`.

- [x] Resolví 2 problemas y los anoté en «Problemas elegidos».
- [x] Cada programa compila con `gcc -Wall -Wextra` **sin errores y sin advertencias**.
- [x] Probé cada programa con el ejemplo, con un caso límite y con un dato inválido.
- [x] La validación compara **el dato leído**, no el contador del ciclo.
- [x] Cada límite y cada tasa del enunciado es una **constante** (`#define`).
- [x] Cada cadena tiene espacio para todas sus letras **más el `'\0'`**.
- [x] Cada programa empieza con comentarios: enunciado, qué se logra, cómo se logra y resultado esperado.
- [x] Cada variable y constante tiene un comentario que explica para qué se usa.
- [x] Los archivos tienen los nombres pedidos y el README está dentro de `UA2/AC2_2da`.
- [x] Las capturas se ven en GitHub (están en `recursos/` con los nombres de esta plantilla).
- [x] Hice commits durante la actividad y un push al final.
- [x] Comprimí la carpeta como `Proyecto02_PrimerNombre_PrimerApellido.zip`.

## Conclusión

**Qué corregí con respecto a la 1.ª oportunidad:** (escriba al menos dos aspectos concretos) El uso de constantes para los limites dichas por el documento, un trabajo mas limpio y bien comentado.

**Qué fue lo más difícil y cómo lo resolví:** Sin duda la parte matematica es lo mas complicado y como lo resolvi;con la ayuda de la calculadora de que esta por defecto en la compu, con calma y probando lo resolvi.
